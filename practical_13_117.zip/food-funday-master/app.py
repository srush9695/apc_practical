from flask import (
    Flask,
    render_template,
    request,
    redirect,
    session,
    url_for,
    flash,
)
from flask_sqlalchemy import SQLAlchemy

import base64
import io
import os
import re

from collections import Counter
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from threading import Lock

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

import torch
import psycopg2

from psycopg2 import sql
from sqlalchemy.engine import URL
from transformers import (
    PreTrainedTokenizerFast,
    BertForSequenceClassification,
    AutoTokenizer,
    AutoModelForSequenceClassification,
)


# ------------------ Project Paths ------------------

BASE_DIR = Path(__file__).resolve().parent

SENTIMENT_MODEL_DIR = BASE_DIR / "training" / "sentiment_model"
SUGGESTION_MODEL_DIR = BASE_DIR / "training" / "suggestion_model"


# ------------------ Flask App Setup ------------------

app = Flask(__name__)

# Local-development fallback retained for compatibility.
# Set FLASK_SECRET_KEY to a strong secret before deployment.
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "secret123")


# ------------------ PostgreSQL Configuration ------------------

DB_USER = os.environ.get("DB_USER", "postgres")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "srushti")
DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "food_data")


# ------------------ Create Database If Needed ------------------

def create_database_if_not_exists():
    conn = None

    try:
        conn = psycopg2.connect(
            dbname="postgres",
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT,
        )

        conn.autocommit = True

        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT 1 FROM pg_catalog.pg_database "
                "WHERE datname = %s",
                (DB_NAME,),
            )

            exists = cursor.fetchone()

            if not exists:
                cursor.execute(
                    sql.SQL("CREATE DATABASE {}").format(
                        sql.Identifier(DB_NAME)
                    )
                )

                print(f"Database '{DB_NAME}' created successfully.")

            else:
                print(f"Database '{DB_NAME}' already exists.")

    except Exception as exc:
        print(f"Database initialization error: {exc}")
        raise

    finally:
        if conn is not None:
            conn.close()


create_database_if_not_exists()

app.config["SQLALCHEMY_DATABASE_URI"] = URL.create(
    drivername="postgresql+psycopg2",
    username=DB_USER,
    password=DB_PASSWORD,
    host=DB_HOST,
    port=int(DB_PORT),
    database=DB_NAME,
)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# ------------------ Device ------------------

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print(f"Model device: {device}")


# ------------------ Sentiment Model ------------------

if not (SENTIMENT_MODEL_DIR / "config.json").is_file():
    raise FileNotFoundError(
        f"Sentiment model not found in: {SENTIMENT_MODEL_DIR}"
    )

sentiment_tokenizer = PreTrainedTokenizerFast(
    tokenizer_file=str(
        SENTIMENT_MODEL_DIR / "tokenizer.json"
    )
)

sentiment_model = BertForSequenceClassification.from_pretrained(
    str(SENTIMENT_MODEL_DIR),
    local_files_only=True,
)

sentiment_model.to(device)
sentiment_model.eval()

_sentiment_lock = Lock()

print("Sentiment model loaded successfully.")


# ------------------ Suggestion Model ------------------

if not (SUGGESTION_MODEL_DIR / "config.json").is_file():
    raise FileNotFoundError(
        "Suggestion model not found. Extract your Colab model into: "
        f"{SUGGESTION_MODEL_DIR}"
    )

suggestion_tokenizer = AutoTokenizer.from_pretrained(
    str(SUGGESTION_MODEL_DIR),
    local_files_only=True,
)

suggestion_model = (
    AutoModelForSequenceClassification.from_pretrained(
        str(SUGGESTION_MODEL_DIR),
        local_files_only=True,
    )
)

if suggestion_model.config.num_labels != 2:
    raise ValueError(
        "Suggestion model must have exactly two labels."
    )

suggestion_model.to(device)
suggestion_model.eval()

_suggestion_lock = Lock()

# Matches the Colab training script:
# 0 = NON_SUGGESTION
# 1 = SUGGESTION
SUGGESTION_LABEL_ID = 1

SUGGESTION_PROBABILITY_THRESHOLD = 0.50

print("Suggestion model loaded successfully.")
print("Architecture:", suggestion_model.__class__.__name__)
print("Label mapping:", suggestion_model.config.id2label)


# ------------------ Sentiment Preprocessing ------------------

NEGATION_FLIP = {
    "not bad": "decent",
    "not terrible": "okay",
    "not horrible": "acceptable",
    "not awful": "fine",
    "not disgusting": "acceptable",
    "not the worst": "okay",
    "not disappointing": "satisfying",
    "not unpleasant": "pleasant",
    "not tasteless": "flavorful",
    "not stale": "fresh",
    "not poor": "good",
    "not mediocre": "good",
}


def preprocess_review(text):
    """Retain the existing sentiment preprocessing behavior."""
    text = re.sub(
        r"\s+",
        " ",
        text or "",
    ).strip().lower()

    for phrase, replacement in NEGATION_FLIP.items():
        text = text.replace(phrase, replacement)

    return text


@lru_cache(maxsize=10000)
def predict_sentiment(review_text):
    """Return 0 for negative and 1 for positive."""
    cleaned_text = preprocess_review(review_text)

    inputs = sentiment_tokenizer(
        cleaned_text,
        return_tensors="pt",
        truncation=True,
        max_length=128,
    )

    inputs = {
        key: value.to(device)
        for key, value in inputs.items()
    }

    with _sentiment_lock:
        with torch.inference_mode():
            logits = sentiment_model(**inputs).logits

            prediction = torch.argmax(
                logits,
                dim=-1,
            ).item()

    return prediction


# ------------------ Trained Suggestion Detection ------------------

def _normalize(text):
    """Normalize quotation marks and spaces without rewriting meaning."""
    text = (
        (text or "")
        .replace("\u00a0", " ")
        .replace("’", "'")
        .replace("‘", "'")
        .replace("“", '"')
        .replace("”", '"')
    )

    return re.sub(r"[ \t]+", " ", text).strip()


@lru_cache(maxsize=10000)
def _cached_suggestion_score(text):
    """Return the suggestion-class softmax score."""
    inputs = suggestion_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=128,
    )

    inputs = {
        key: value.to(device)
        for key, value in inputs.items()
    }

    with _suggestion_lock:
        with torch.inference_mode():
            logits = suggestion_model(**inputs).logits

            score = torch.softmax(
                logits,
                dim=-1,
            )[0, SUGGESTION_LABEL_ID].item()

    return float(score)


def predict_suggestion(
    text,
    threshold=SUGGESTION_PROBABILITY_THRESHOLD,
):
    """Return (is_suggestion, suggestion_score)."""
    normalized_text = _normalize(text)

    if not normalized_text:
        return False, 0.0

    score = _cached_suggestion_score(normalized_text)

    return score >= threshold, score


_SUGGESTION_CLAUSE_SPLIT = re.compile(
    r"\s*;\s*|,\s*(?:but|however)\b\s*",
    re.IGNORECASE,
)


def _split_clauses(sentence):
    """Conservatively split contrastive clauses."""
    return [
        clause.strip(" ,")
        for clause in _SUGGESTION_CLAUSE_SPLIT.split(sentence)
        if clause.strip(" ,")
    ]


@lru_cache(maxsize=5000)
def _extract_suggestions_cached(review_text):
    """Cache immutable extraction results for repeated page visits."""
    normalized_text = _normalize(review_text)

    if not normalized_text:
        return ()

    sentences = re.split(
        r"(?<=[.!?।])\s+|\n+",
        normalized_text,
    )

    found = []
    seen = set()

    for sentence in sentences:
        sentence = sentence.strip()

        if not sentence:
            continue

        for clause in _split_clauses(sentence):
            detected, _ = predict_suggestion(clause)

            if not detected:
                continue

            key = clause.casefold()

            if key in seen:
                continue

            found.append(clause)
            seen.add(key)

    return tuple(found)


def extract_suggestions(review_text):
    """Return suggestion sentences/clauses as a list of strings."""
    return list(
        _extract_suggestions_cached(review_text or "")
    )


# ------------------ Suggestion Categories ------------------

SUGGESTION_CATEGORIES = [
    (
        "Taste & Quality",
        r"चव|मसाला|तिखट|मीठ|तेल|"
        r"\btast\w*|\bflavou?r\w*|\bspic\w*|\bsalt\w*|"
        r"\bsweet\w*|\bsugar\b|\bsour\b|\bbland\b|"
        r"\bmasala\b|\boil\w*|\bcrisp\w*|\bsauce\b|"
        r"\bgravy\b|\bcook\w*|\braw\b|\bburnt\b|"
        r"\btexture\b|\bcheese\b|\bbutter\b|\bgarlic\b|"
        r"\bchill?i\b|\bpepper\b|\bfresh\b|\bstale\b|"
        r"\bsmok\w*|\bgrill\w*|\bhot\b|\bhotter\b|"
        r"\bcold\b|\bwarmer\b|\bsoggy\b|\bdry\b|\bjuicy\b",
    ),
    (
        "Portion & Price",
        r"किंमत|प्रमाण|\bportions?\b|\bquantity\b|"
        r"\bprice\w*|\bcost\w*|expensive|\bcheap\b|"
        r"discount|\boffers?\b|\bcombo\b|\bsize\b|"
        r"\brate\b|value for money|\bserving size\b",
    ),
    (
        "Menu & Variety",
        r"\bmenu\b|\bvariety\b|\boptions?\b|new dish|"
        r"\bvegan\b|\bjain\b|\bhealthy\b|side dish|"
        r"accompaniment|\bchutney\b|\bonion rings?\b|"
        r"\bsalad\b|\bdips?\b|\bsides?\b|\braita\b|"
        r"\ballergens?\b|\bingredients?\b",
    ),
    (
        "Service",
        r"सेवा|उशीर|\bservice\b|\bstaff\b|\bwaiters?\b|"
        r"\bwaitress\w*|\bwait(?:ing)?\b|\bdeliver\w*|"
        r"\blate\b|\bslow\b|packing|packaging|"
        r"behaviou?r|attitude|\brude\b|\bmanager\b|"
        r"\bcontainers?\b|\bdispatch\b|\bcutlery\b",
    ),
    (
        "Presentation",
        r"presentation|plating|garnish\w*|decorat\w*|"
        r"\bappearance\b|\blooks?\b|colou?r\w*",
    ),
    (
        "Hygiene & Ambience",
        r"\bclean\w*|hygien\w*|\bdirty\b|ambien\w*|"
        r"seating|\bmusic\b|washroom|toilet|"
        r"\bsmell\w*|parking|\bac\b|\bfan\b|"
        r"\btables?\b|decor\b|lighting|\bnoisy\b|crowded",
    ),
]


def categorize_suggestion(text):
    """Assign the category with the most keyword matches."""
    best_category = "General"
    best_score = 0

    for category, pattern in SUGGESTION_CATEGORIES:
        score = len(
            re.findall(
                pattern,
                text,
                re.IGNORECASE,
            )
        )

        if score > best_score:
            best_category = category
            best_score = score

    return best_category


# ------------------ Matplotlib Helpers ------------------

POS_COLOR = "#36a2eb"
NEG_COLOR = "#ff6384"
TOT_COLOR = "#ffce56"

_chart_lock = Lock()


def fig_to_base64(fig):
    buffer = io.BytesIO()

    try:
        fig.savefig(
            buffer,
            format="png",
            dpi=110,
            bbox_inches="tight",
        )

        return base64.b64encode(
            buffer.getvalue()
        ).decode("utf-8")

    finally:
        plt.close(fig)
        buffer.close()


def _empty_chart(message="No reviews yet", size=(5, 4)):
    fig, ax = plt.subplots(figsize=size)

    ax.text(
        0.5,
        0.5,
        message,
        ha="center",
        va="center",
        fontsize=13,
        color="gray",
    )

    ax.axis("off")

    return fig_to_base64(fig)


def make_bar_chart(labels, positive, negative, total):
    if not labels:
        return _empty_chart("No food items yet", (10, 4))

    x = list(range(len(labels)))
    width = 0.35  # each bar's width; two bars sit side by side, touching

    fig, ax = plt.subplots(figsize=(10, 4.5))

    # Left bar: stacked Positive + Negative
    ax.bar([i - width / 2 for i in x], positive, width,
           label="Positive Reviews", color=POS_COLOR)

    ax.bar([i - width / 2 for i in x], negative, width,
           bottom=positive,
           label="Negative Reviews", color=NEG_COLOR)

    # Right bar: Total (yellow), attached to the stacked bar
    total_bars = ax.bar([i + width / 2 for i in x], total, width,
                        label="Total Reviews", color=TOT_COLOR)

    # Show the total count above the yellow bar
    ax.bar_label(total_bars, padding=2, fontsize=9)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=25, ha="right")
    ax.set_ylabel("Number of Reviews")
    ax.set_title("Review Summary Per Food", fontweight="bold")
    ax.set_ylim(0, max(total, default=1) + 1)
    ax.legend(loc="upper right")
    ax.spines[["top", "right"]].set_visible(False)
    ax.yaxis.get_major_locator().set_params(integer=True)

    return fig_to_base64(fig)


def make_pie_chart(pos, neg, title=""):
    if pos + neg == 0:
        return _empty_chart("No reviews for this item")

    fig, ax = plt.subplots(figsize=(5, 4))

    ax.pie(
        [pos, neg],
        labels=["Positive", "Negative"],
        colors=[POS_COLOR, NEG_COLOR],
        autopct="%1.1f%%",
        startangle=90,
        wedgeprops={"edgecolor": "white"},
    )

    ax.set_title(title, fontweight="bold")

    return fig_to_base64(fig)


def make_overall_donut(pos, neg):
    if pos + neg == 0:
        return _empty_chart("No reviews yet")

    fig, ax = plt.subplots(figsize=(5, 4))

    ax.pie(
        [pos, neg],
        labels=["Positive Reviews", "Negative Reviews"],
        colors=["#28a745", "#dc3545"],
        autopct="%1.1f%%",
        startangle=90,
        wedgeprops={
            "width": 0.45,
            "edgecolor": "white",
        },
    )

    ax.set_title(
        "Overall Restaurant Sentiment",
        fontweight="bold",
    )

    return fig_to_base64(fig)


def make_trend_chart(labels, positive, negative):
    if not labels:
        return _empty_chart(
            "No trend data yet",
            (10, 4),
        )

    fig, ax = plt.subplots(figsize=(10, 4))

    x = list(range(len(labels)))

    ax.plot(
        x,
        positive,
        marker="o",
        color="green",
        label="Positive Reviews",
    )

    ax.fill_between(
        x,
        positive,
        alpha=0.15,
        color="green",
    )

    ax.plot(
        x,
        negative,
        marker="o",
        color="red",
        label="Negative Reviews",
    )

    ax.fill_between(
        x,
        negative,
        alpha=0.15,
        color="red",
    )

    ax.set_xticks(x)
    ax.set_xticklabels(
        labels,
        rotation=25,
        ha="right",
    )

    ax.set_ylim(bottom=0)
    ax.set_ylabel("Number of Reviews")
    ax.set_title(
        "Sentiment Trend Over Time",
        fontweight="bold",
    )

    ax.legend()
    ax.grid(alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    ax.yaxis.get_major_locator().set_params(integer=True)

    return fig_to_base64(fig)


# ------------------ Input Validation ------------------

EMAIL_RE = re.compile(
    r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
)

MOBILE_RE = re.compile(r"^[6-9]\d{9}$")


def validate_email(email):
    if not EMAIL_RE.fullmatch(email):
        return "Enter a valid email address."

    return None


def normalize_mobile(phone):
    phone = re.sub(r"[\s\-]", "", phone)

    if phone.startswith("+91"):
        phone = phone[3:]

    elif phone.startswith("91") and len(phone) == 12:
        phone = phone[2:]

    return phone


def validate_mobile(phone):
    if not MOBILE_RE.fullmatch(phone):
        return (
            "Enter a valid 10-digit mobile number "
            "starting with 6-9."
        )

    return None


def validate_password(password):
    if len(password) < 8:
        return "Password must be at least 8 characters."

    if not re.search(r"[A-Z]", password):
        return "Password must contain an uppercase letter."

    if not re.search(r"[a-z]", password):
        return "Password must contain a lowercase letter."

    if not re.search(r"\d", password):
        return "Password must contain a digit."

    if not re.search(r"[^A-Za-z0-9]", password):
        return "Password must contain a special character."

    return None


# ------------------ Database Models ------------------

class Customer(db.Model):
    __tablename__ = "customers"

    customer_id = db.Column(
        db.Integer,
        primary_key=True,
        autoincrement=True,
    )

    name = db.Column(db.String(100), nullable=False)

    email = db.Column(
        db.String(120),
        unique=True,
        nullable=False,
    )

    phone_number = db.Column(
        db.String(15),
        unique=True,
        nullable=False,
    )

    # Existing storage format retained for database compatibility.
    # Migrate to password hashes before deployment.
    password = db.Column(db.String(200), nullable=False)


class FoodItem(db.Model):
    __tablename__ = "food_items"

    food_id = db.Column(
        db.Integer,
        primary_key=True,
    )

    food_name = db.Column(
        db.String(100),
        nullable=False,
    )

    image = db.Column(
        db.LargeBinary,
        nullable=False,
    )


class Review(db.Model):
    __tablename__ = "reviews"

    review_id = db.Column(
        db.Integer,
        primary_key=True,
    )

    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("customers.customer_id"),
        nullable=False,
    )

    food_id = db.Column(
        db.Integer,
        db.ForeignKey("food_items.food_id"),
        nullable=False,
    )

    review_text = db.Column(
        db.Text,
        nullable=False,
    )

    created_at = db.Column(
        db.DateTime,
        server_default=db.func.now(),
    )

    customer = db.relationship(
        "Customer",
        backref="reviews",
    )

    food = db.relationship(
        "FoodItem",
        backref="reviews",
    )


class FoodStats(db.Model):
    __tablename__ = "food_stats"

    id = db.Column(
        db.Integer,
        primary_key=True,
    )

    food_id = db.Column(
        db.Integer,
        db.ForeignKey("food_items.food_id"),
        nullable=False,
    )

    total_reviews = db.Column(
        db.Integer,
        default=0,
        nullable=False,
    )

    positive_reviews = db.Column(
        db.Integer,
        default=0,
        nullable=False,
    )

    negative_reviews = db.Column(
        db.Integer,
        default=0,
        nullable=False,
    )

    positive_rate = db.Column(
        db.Float,
        default=0.0,
    )

    negative_rate = db.Column(
        db.Float,
        default=0.0,
    )

    food = db.relationship(
        "FoodItem",
        backref="stats",
    )


# ------------------ Suggestion Review Collection ------------------

def get_suggestion_reviews(with_sentiment=False):
    result = []

    reviews = (
        Review.query
        .options(
            db.joinedload(Review.customer),
            db.joinedload(Review.food),
        )
        .order_by(Review.created_at.desc())
        .all()
    )

    for review_record in reviews:
        found = extract_suggestions(
            review_record.review_text
        )

        if not found:
            continue

        suggestion_text = " ".join(found)

        item = {
            "review_id": review_record.review_id,
            "customer": (
                review_record.customer.name
                if review_record.customer
                else "Unknown"
            ),
            "food": (
                review_record.food.food_name
                if review_record.food
                else "Unknown"
            ),
            "full_review": review_record.review_text,
            "suggestion": suggestion_text,
            "category": categorize_suggestion(
                suggestion_text
            ),
            "created_at": review_record.created_at,
        }

        if with_sentiment:
            sentiment = predict_sentiment(
                review_record.review_text
            )

            item["sentiment"] = (
                "Positive" if sentiment == 1 else "Negative"
            )

        result.append(item)

    return result


# ------------------ Home Routes ------------------

@app.route("/")
def home():
    return redirect(url_for("index"))


@app.route("/index")
def index():
    return render_template("index.html")


# ------------------ Register ------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()

        email = (
            request.form.get("email", "")
            .strip()
            .lower()
        )

        phone = normalize_mobile(
            request.form.get("phone", "").strip()
        )

        password = request.form.get("password", "")

        confirm = request.form.get(
            "confirm_password",
            password,
        )

        if len(name) < 2 or len(name) > 100:
            flash("Enter a name between 2 and 100 characters.")
            return redirect(url_for("register"))

        errors = (
            validate_email(email),
            validate_mobile(phone),
            validate_password(password),
        )

        for error in errors:
            if error:
                flash(error)
                return redirect(url_for("register"))

        if len(email) > 120:
            flash("Email address is too long.")
            return redirect(url_for("register"))

        if len(password) > 200:
            flash("Password is too long.")
            return redirect(url_for("register"))

        if password != confirm:
            flash("Passwords do not match.")
            return redirect(url_for("register"))

        if Customer.query.filter_by(email=email).first():
            flash("Email already registered. Please login.")
            return redirect(url_for("register"))

        if Customer.query.filter_by(
            phone_number=phone
        ).first():
            flash("Mobile number already registered.")
            return redirect(url_for("register"))

        new_customer = Customer(
            name=name,
            email=email,
            phone_number=phone,
            password=password,
        )

        db.session.add(new_customer)
        db.session.commit()

        session["user_id"] = new_customer.customer_id

        return redirect(url_for("review"))

    return render_template("register.html")


# ------------------ Login ------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (
            request.form.get("email", "")
            .strip()
            .lower()
        )

        password = request.form.get("password", "")

        if validate_email(email):
            flash("Enter a valid email address.")
            return redirect(url_for("login"))

        customer = Customer.query.filter_by(
            email=email
        ).first()

        if customer and customer.password == password:
            session["user_id"] = customer.customer_id

            return redirect(url_for("review"))

        flash("Invalid Email or Password")

        return redirect(url_for("login"))

    return render_template("login.html")


# ------------------ Review Page ------------------

@app.route("/review")
def review():
    if "user_id" not in session:
        return redirect(url_for("login"))

    customer = db.session.get(
        Customer,
        session["user_id"],
    )

    if customer is None:
        session.pop("user_id", None)
        return redirect(url_for("login"))

    food_items = FoodItem.query.all()
    food_list = []

    for food in food_items:
        image_base64 = (
            base64.b64encode(food.image).decode("utf-8")
            if food.image
            else None
        )

        reviews = (
            Review.query
            .options(db.joinedload(Review.customer))
            .filter_by(food_id=food.food_id)
            .order_by(Review.created_at.desc())
            .all()
        )

        review_list = []

        for review_record in reviews:
            review_list.append(
                {
                    "text": review_record.review_text,
                    "customer_name": (
                        review_record.customer.name
                        if review_record.customer
                        else "Unknown"
                    ),
                    "created_at": review_record.created_at,
                }
            )

        food_list.append(
            {
                "id": food.food_id,
                "name": food.food_name,
                "image": image_base64,
                "reviews": review_list,
            }
        )

    return render_template(
        "review.html",
        food_items=food_list,
        customer_name=customer.name,
    )


# ------------------ Submit Review ------------------

@app.route("/submit_review", methods=["POST"])
def submit_review():
    if "user_id" not in session:
        return redirect(url_for("login"))

    customer = db.session.get(
        Customer,
        session["user_id"],
    )

    if customer is None:
        session.pop("user_id", None)
        return redirect(url_for("login"))

    food_id = request.form.get(
        "food_id",
        type=int,
    )

    review_text = request.form.get(
        "review_text",
        "",
    ).strip()

    if food_id is None:
        flash("Select a valid food item.")
        return redirect(url_for("review"))

    food = db.session.get(FoodItem, food_id)

    if food is None:
        flash("Food item not found.")
        return redirect(url_for("review"))

    if not review_text:
        flash("Please enter a review.")
        return redirect(url_for("review"))

    sentiment = predict_sentiment(review_text)

    new_review = Review(
        customer_id=customer.customer_id,
        food_id=food.food_id,
        review_text=review_text,
    )

    db.session.add(new_review)

    stats = FoodStats.query.filter_by(
        food_id=food.food_id
    ).first()

    if stats is None:
        stats = FoodStats(
            food_id=food.food_id,
            total_reviews=0,
            positive_reviews=0,
            negative_reviews=0,
        )

        db.session.add(stats)

    stats.total_reviews = (stats.total_reviews or 0) + 1

    if sentiment == 1:
        stats.positive_reviews = (
            stats.positive_reviews or 0
        ) + 1

    else:
        stats.negative_reviews = (
            stats.negative_reviews or 0
        ) + 1

    total = stats.total_reviews
    positive = stats.positive_reviews or 0
    negative = stats.negative_reviews or 0

    stats.positive_rate = round(
        positive / total * 100,
        1,
    )

    stats.negative_rate = round(
        negative / total * 100,
        1,
    )

    db.session.commit()

    flash("Review submitted successfully!")

    return redirect(url_for("review"))


# ------------------ Admin Login ------------------

@app.route(
    "/admin/admin_login",
    methods=["GET", "POST"],
)
def admin_login():
    admin_username = os.environ.get(
        "ADMIN_USERNAME",
        "admin",
    )

    admin_password = os.environ.get(
        "ADMIN_PASSWORD",
        "admin123",
    )

    verification_code = os.environ.get(
        "ADMIN_VERIFICATION_CODE",
        "FOOD2024",
    )

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        code = request.form.get("verification_code", "")

        if (
            username == admin_username
            and password == admin_password
            and code == verification_code
        ):
            session["admin"] = True

            return redirect(url_for("admin_dashboard"))

        flash("Invalid credentials or verification code!")

    return render_template("admin/admin_login.html")


# ------------------ Admin Dashboard ------------------

@app.route("/admin/admin_dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    return render_template(
        "admin/admin_dashboard.html",
        food_count=FoodItem.query.count(),
        review_count=Review.query.count(),
        customer_count=Customer.query.count(),
        suggestion_count=len(get_suggestion_reviews()),
    )


# ------------------ Admin Lists ------------------

@app.route("/admin/food_list")
def food_list():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    food_items = FoodItem.query.all()

    return render_template(
        "admin/food_list.html",
        food_items=food_items,
    )


@app.route("/admin/customer_list")
def customer_list():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    customers = Customer.query.all()

    return render_template(
        "admin/customer_list.html",
        customers=customers,
    )


@app.route("/admin/review_list")
def review_list():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    reviews = (
        Review.query
        .options(
            db.joinedload(Review.customer),
            db.joinedload(Review.food),
        )
        .all()
    )

    return render_template(
        "admin/review_list.html",
        reviews=reviews,
    )


# ------------------ Template Filter ------------------

@app.template_filter("b64encode")
def b64encode_filter(data):
    if not data:
        return ""

    return base64.b64encode(data).decode("utf-8")


# ------------------ Admin Add Food ------------------

@app.route(
    "/admin/add_food",
    methods=["GET", "POST"],
)
def add_food():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    if request.method == "POST":
        food_name = request.form.get(
            "food_name",
            "",
        ).strip()

        image = request.files.get("food_image")

        if not food_name or len(food_name) > 100:
            flash(
                "Enter a food name between 1 and 100 characters."
            )

            return redirect(url_for("add_food"))

        if image is None or not image.filename:
            flash("Please select a food image.")
            return redirect(url_for("add_food"))

        image_data = image.read()

        if not image_data:
            flash("The selected image is empty.")
            return redirect(url_for("add_food"))

        new_food = FoodItem(
            food_name=food_name,
            image=image_data,
        )

        db.session.add(new_food)
        db.session.commit()

        flash("Food Item Added Successfully!")

        return redirect(url_for("add_food"))

    return render_template("admin/add_food.html")


# ------------------ Admin Sentiment Analysis ------------------

@app.route("/admin/sentiment_analysis")
def sentiment_analysis():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    food_items = FoodItem.query.all()

    analysis_data = []

    most_liked = None
    most_disliked = None

    # (rate, latest review time) – compared as a tuple,
    # so the time only matters when the rates are equal.
    best_liked_key = None
    best_disliked_key = None

    total_positive = 0
    total_negative = 0

    trend_data = {}

    for food in food_items:
        reviews = Review.query.filter_by(
            food_id=food.food_id
        ).all()

        total_reviews = len(reviews)
        positive_reviews = 0
        negative_reviews = 0

        latest_positive_at = None
        latest_negative_at = None

        for review_record in reviews:
            sentiment = predict_sentiment(
                review_record.review_text
            )

            created = review_record.created_at

            if sentiment == 1:
                positive_reviews += 1
                total_positive += 1

                if created is not None and (
                    latest_positive_at is None
                    or created > latest_positive_at
                ):
                    latest_positive_at = created

            else:
                negative_reviews += 1
                total_negative += 1

                if created is not None and (
                    latest_negative_at is None
                    or created > latest_negative_at
                ):
                    latest_negative_at = created

            if review_record.created_at is not None:
                month = review_record.created_at.strftime(
                    "%Y-%m"
                )

                if month not in trend_data:
                    trend_data[month] = {
                        "positive": 0,
                        "negative": 0,
                    }

                key = (
                    "positive"
                    if sentiment == 1
                    else "negative"
                )

                trend_data[month][key] += 1

        if total_reviews:
            positive_rate = round(
                positive_reviews / total_reviews * 100,
                1,
            )

            negative_rate = round(
                negative_reviews / total_reviews * 100,
                1,
            )

        else:
            positive_rate = 0.0
            negative_rate = 0.0

        stats = FoodStats.query.filter_by(
            food_id=food.food_id
        ).first()

        if stats is None:
            stats = FoodStats(food_id=food.food_id)
            db.session.add(stats)

        stats.total_reviews = total_reviews
        stats.positive_reviews = positive_reviews
        stats.negative_reviews = negative_reviews
        stats.positive_rate = positive_rate
        stats.negative_rate = negative_rate

        analysis_data.append(
            {
                "food_name": food.food_name,
                "total": total_reviews,
                "positive": positive_reviews,
                "negative": negative_reviews,
                "positive_rate": positive_rate,
                "negative_rate": negative_rate,
            }
        )

        # Higher rate wins; on a tie, the food with the
        # more recent review of that sentiment wins.
        if positive_reviews > 0:
            liked_key = (
                positive_rate,
                latest_positive_at or datetime.min,
            )

            if (
                best_liked_key is None
                or liked_key > best_liked_key
            ):
                best_liked_key = liked_key
                most_liked = food.food_name

        if negative_reviews > 0:
            disliked_key = (
                negative_rate,
                latest_negative_at or datetime.min,
            )

            if (
                best_disliked_key is None
                or disliked_key > best_disliked_key
            ):
                best_disliked_key = disliked_key
                most_disliked = food.food_name

    db.session.commit()

    most_liked = most_liked or "No liked food yet"
    most_disliked = most_disliked or "No disliked food yet"

    trend_labels = sorted(trend_data)

    trend_positive = [
        trend_data[month]["positive"]
        for month in trend_labels
    ]

    trend_negative = [
        trend_data[month]["negative"]
        for month in trend_labels
    ]

    labels = [
        item["food_name"]
        for item in analysis_data
    ]

    with _chart_lock:
        bar_chart = make_bar_chart(
            labels,
            [item["positive"] for item in analysis_data],
            [item["negative"] for item in analysis_data],
            [item["total"] for item in analysis_data],
        )

        food_pies = [
            {
                "name": item["food_name"],
                "img": make_pie_chart(
                    item["positive"],
                    item["negative"],
                    item["food_name"],
                ),
            }
            for item in analysis_data
        ]

        overall_chart = make_overall_donut(
            total_positive,
            total_negative,
        )

        trend_chart = make_trend_chart(
            trend_labels,
            trend_positive,
            trend_negative,
        )

    return render_template(
        "admin/sentiment_analysis.html",
        analysis=analysis_data,
        most_liked=most_liked,
        most_disliked=most_disliked,
        bar_chart=bar_chart,
        food_pies=food_pies,
        overall_chart=overall_chart,
        trend_chart=trend_chart,
    )


# ------------------ Admin Suggestions ------------------

@app.route("/admin/suggestions")
def admin_suggestions():
    if not session.get("admin"):
        return redirect(url_for("admin_login"))

    suggestions = get_suggestion_reviews(
        with_sentiment=True
    )

    category_counts = Counter(
        item["category"]
        for item in suggestions
    )

    foods = sorted(
        {
            item["food"]
            for item in suggestions
        }
    )

    return render_template(
        "admin/suggestions.html",
        suggestions=suggestions,
        category_counts=dict(category_counts),
        foods=foods,
        total_reviews=Review.query.count(),
    )


# ------------------ Logout ------------------

@app.route("/admin/logout")
def logout():
    session.clear()

    return redirect(url_for("login"))


# ------------------ Initialize Tables ------------------

with app.app_context():
    db.create_all()

    print("All tables created/verified successfully.")


# ------------------ Run ------------------

if __name__ == "__main__":
    # Local development only.
    # Disable debug before deployment.
    app.run(
        debug=True,
        use_reloader=False,
    )
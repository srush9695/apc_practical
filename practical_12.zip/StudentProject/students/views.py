from django.shortcuts import render, redirect, get_object_or_404
from .models import Student

def home(request):
    students = Student.objects.all()

    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        course = request.POST.get("course")

        Student.objects.create(
            name=name,
            email=email,
            course=course
        )

        return redirect("home")

    return render(
        request,
        "students/home.html",
        {"students": students}
    )


def delete_student(request, id):
    student = get_object_or_404(Student, id=id)

    if request.method == "POST":
        student.delete()

    return redirect("home")
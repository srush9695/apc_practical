from question9.account import create_account, get_balance
from question9.transaction import deposit, withdraw
from question9.loan import calculate_loan

name = input("Enter name: ")
balance = float(input("Enter initial balance: "))

account = create_account(name, balance)

deposit(account, 500)
withdraw(account, 200)

print("Account Holder:", account["name"])
print("Balance:", get_balance(account))

interest, total = calculate_loan(10000, 5, 2)

print("Loan Interest:", interest)
print("Total Loan Amount:", total)

def student_details():
    print("Student Name: Amit")
    print("Roll No: 101")

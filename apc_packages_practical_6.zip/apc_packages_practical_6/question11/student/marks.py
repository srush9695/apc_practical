def student_marks():
    print("Marks: 85")

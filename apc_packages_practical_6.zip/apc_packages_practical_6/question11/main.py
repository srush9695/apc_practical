from student.details import student_details
from student.marks import student_marks
from faculty.details import faculty_details

print("STUDENT INFORMATION")
student_details()
student_marks()

print("\nFACULTY INFORMATION")
faculty_details()

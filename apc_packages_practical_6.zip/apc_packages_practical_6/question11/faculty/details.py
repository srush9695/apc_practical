def faculty_details():
    print("Faculty Name: Prof. Sharma")
    print("Department: Computer Engineering")

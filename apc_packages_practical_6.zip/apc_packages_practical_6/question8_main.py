from question8.marks import total, percentage
from question8.grade import grade
from question8.attendance import eligible

marks = [80, 75, 90, 85, 70]

attendance = float(input("Enter attendance percentage: "))

t = total(marks)
p = percentage(marks)

print("Total:", t)
print("Percentage:", p)
print("Grade:", grade(p))
print("Attendance:", eligible(attendance))

def add_book(title):
    print("Book added:", title)


def display_book(title):
    print("Book:", title)

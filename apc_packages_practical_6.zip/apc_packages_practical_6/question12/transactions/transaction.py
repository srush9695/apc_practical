def issue_book(book, member):
    print(book, "issued to", member)


def return_book(book):
    print(book, "returned")

def add_member(name):
    print("Member added:", name)


def display_member(name):
    print("Member:", name)

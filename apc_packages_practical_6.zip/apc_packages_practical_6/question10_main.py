from question10.cleaning import remove_punctuation, remove_extra_spaces
from question10.tokenization import tokenize
from question10.frequency import word_frequency

text = input("Enter text: ")

text = remove_punctuation(text)
text = remove_extra_spaces(text)

words = tokenize(text)
frequency = word_frequency(words)

print("Cleaned Text:", text)
print("Tokens:", words)
print("Word Frequency:", frequency)

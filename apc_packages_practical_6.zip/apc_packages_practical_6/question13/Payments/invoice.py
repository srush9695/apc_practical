def generate_invoice(order):
    product_name = order["product"]["name"]
    customer_name = order["customer"]["name"]

    return f"Invoice generated for {customer_name} - {product_name}"

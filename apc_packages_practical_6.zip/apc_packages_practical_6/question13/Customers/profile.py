def display_customer(name, email):
    return {
        "name": name,
        "email": email
    }

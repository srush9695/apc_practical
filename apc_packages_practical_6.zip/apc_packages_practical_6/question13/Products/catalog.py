def display_product(product):
    print("Product Name:", product["name"])
    print("Product Price: Rs.", product["price"])

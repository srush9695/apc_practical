from patient.patient import add_patient
from doctor.doctor import add_doctor
from billing.bill import generate_bill
from records.medical import add_record

print("PATIENT DETAILS")
add_patient("Amit", 25)

print("\nDOCTOR DETAILS")
add_doctor("Dr. Sharma", "Cardiology")

print("\nMEDICAL RECORD")
add_record("Amit", "Fever")

print("\nBILLING")
generate_bill(1500)

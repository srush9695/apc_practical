def generate_bill(amount):
    print("Medical Bill:", amount)

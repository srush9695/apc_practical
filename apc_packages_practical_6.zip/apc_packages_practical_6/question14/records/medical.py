def add_record(patient, disease):
    print("Patient:", patient)
    print("Disease:", disease)

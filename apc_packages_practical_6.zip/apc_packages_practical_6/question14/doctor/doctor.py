def add_doctor(name, department):
    print("Doctor:", name)
    print("Department:", department)

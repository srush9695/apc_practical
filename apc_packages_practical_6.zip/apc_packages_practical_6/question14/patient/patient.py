def add_patient(name, age):
    print("Patient Name:", name)
    print("Age:", age)

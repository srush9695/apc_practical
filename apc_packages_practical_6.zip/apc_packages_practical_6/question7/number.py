def prime(n):
    if n < 2:
        return False

    for i in range(2, n):
        if n % i == 0:
            return False

    return True


def palindrome(n):
    return str(n) == str(n)[::-1]


def armstrong(n):
    digits = str(n)
    return sum(int(d) ** len(digits) for d in digits) == n
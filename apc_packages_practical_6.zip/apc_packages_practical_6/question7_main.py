from question7.basic import add, subtract, multiply
from question7.number import prime, palindrome, armstrong
from question7.statistics import mean, maximum, minimum

a = 10
b = 5
numbers = [10, 20, 30, 40, 50]

print("Addition:", add(a, b))
print("Subtraction:", subtract(a, b))
print("Multiplication:", multiply(a, b))

n = 121

print("Prime:", prime(n))
print("Palindrome:", palindrome(n))
print("Armstrong:", armstrong(n))

print("Mean:", mean(numbers))
print("Maximum:", maximum(numbers))
print("Minimum:", minimum(numbers))

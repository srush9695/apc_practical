def create_account(name, balance):
    return {
        "name": name,
        "balance": balance
    }


def get_balance(account):
    return account["balance"]

import student

marks = []

for i in range(5):
    m = float(input("Enter marks: "))
    marks.append(m)

t = student.total(marks)
p = student.percentage(marks)
g = student.grade(p)

print("Total:", t)
print("Percentage:", p)
print("Grade:", g)

import string_utils

s = input("Enter a string: ")

print("Vowels:", string_utils.count_vowels(s))
print("Reverse:", string_utils.reverse_string(s))
print("Palindrome:", string_utils.palindrome(s))
print("Words:", string_utils.count_words(s))
print("Without spaces:", string_utils.remove_spaces(s))

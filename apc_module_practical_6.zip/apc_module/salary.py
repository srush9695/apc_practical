def gross_salary(basic, hra, da):
    return basic + hra + da


def deductions(gross):
    return gross * 0.10


def net_salary(gross, deduction):
    return gross - deduction
